import cloudinary
import cloudinary.uploader

cloudinary.config(
  cloud_name = "your-cloud-name",
  api_key = "your-api-key",
  api_secret = "your-api-secret"
)

def upload_to_cloudinary(file):
    result = cloudinary.uploader.upload(file.file)
    return result["secure_url"]
