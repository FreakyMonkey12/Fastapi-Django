import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_verification_email(email: str, token: str):
    msg = MIMEMultipart()
    msg['From'] = "your-email@example.com"
    msg['To'] = email
    msg['Subject'] = "Verify your email"

    body = f"Please verify your email using this token: {token}"
    msg.attach(MIMEText(body, 'plain'))

    server = smtplib.SMTP('smtp.example.com', 587)
    server.starttls()
    server.login(msg['From'], "your-password")
    text = msg.as_string()
    server.sendmail(msg['From'], msg['To'], text)
    server.quit()
