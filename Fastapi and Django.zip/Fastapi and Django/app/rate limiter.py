from fastapi import HTTPException, status
from fastapi_limiter.depends import RateLimiter

def limit(rate: str):
    return RateLimiter(times=int(rate.split("/")[0]), seconds=int(rate.split("/")[1][:-1]), prefix="rl:")
